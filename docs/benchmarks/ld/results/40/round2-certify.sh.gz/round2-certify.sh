#!/usr/bin/env bash
set -euo pipefail
export PATH="$HOME/.pixi/bin:$PATH"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 ZARR_THREADING__MAX_WORKERS=1
export OGLD_STORES=/data/opengwasdb/work/ogld/stores
S=/data/opengwasdb/work/ogld/scratch/40
pixi reinstall --locked -e dev ogld
uptime
taskset -c 0-7 pixi run -e dev python scripts/bench/fast_decode.py step1 --target local --case clump --cold-only --analyses OGS-00012__GCST90476460 --r2 .01 --zarr-threads 1 --out "$S/clean-isolated.jsonl"
uptime
taskset -c 0-7 pixi run -e dev python "$S/phases.py" step1 --target local --case clump --cold-only --zarr-threads 1 --out "$S/all-local.jsonl"
uptime
taskset -c 0-7 pixi run -e dev python "$S/40r2-io-only.py"
uptime
taskset -c 0-7 pixi run -e dev python "$S/40-answers.py" "$S/head-answers.npz"
HEAD_ANSWERS="$S/head-answers.npz" pixi run -e dev python - <<'PY'
import os,numpy as np
before=np.load('/tmp/40-tip-answers.npz');after=np.load(os.environ['HEAD_ANSWERS'])
assert before.files==after.files
for k in before.files:
 a,b=before[k],after[k]
 assert (a.dtype,a.shape)==(b.dtype,b.shape),k
 assert a.tobytes()==b.tobytes(),k
print(len(before.files),'arrays: dtype, shape and every byte identical')
PY
uptime
taskset -c 0-7 pixi run -e dev test-realdata
uptime
taskset -c 0-7 pixi run -e dev acceptance-clump
uptime
taskset -c 0-7 pixi run -e dev python "$S/phases.py" step1 --target local http10 http50 --case proxies scattered region --seeds 1 --zarr-threads 1 --out "$S/reads.jsonl"
uptime
taskset -c 0-7 pixi run -e dev python "$S/phases.py" step1 --target local http10 http50 --case clump --cold-only --analyses OGS-00009__ukb-b-4171 OGS-00011__GCST90319613 OGS-00011__GCST90025965 OGS-00011__GCST90029004 --zarr-threads 1 --out "$S/clump-http.jsonl"
uptime
pixi run -e dev lint
pixi run -e dev typecheck
taskset -c 0-7 pixi run -e dev test -n 0
uptime
taskset -c 0-7 pixi run -e dev test-cov -n 0
uptime
python3 quality/bin/gate.py --postflight
GITHUB_BASE_REF=orch/1-ld-stores python3 quality/bin/gate.py --changed
uptime
echo CERTIFICATION_COMPLETE
