"""Disposable #40 measurement: phase times overlap; worker CPU excludes waiting."""
import io
import json
import os
import resource
import sys
import threading
import time
from collections import Counter

sys.path.insert(0, os.path.join(os.getcwd(), "scripts/bench"))
import fast_decode
import latency
from ogld.store import location
from ogld.store.reader import StoreReader

fast_decode.install()
original_job = location._NumericDecoder._into
original_strings = StoreReader._strings
original_timed = latency.Bench.timed
original_env = latency.environment
cpu = Counter()
counts = Counter()
lock = threading.Lock()
strings = 0.0


def job(self, data, offset, chunks, out):
    start = time.thread_time()
    try:
        return original_job(self, data, offset, chunks, out)
    finally:
        elapsed = time.thread_time() - start
        with lock:
            key = f"{self.dtype.str}:{self.size}"
            cpu[key] += elapsed
            counts[key] += len(chunks)


def string_read(self, *args, **kwargs):
    global strings
    start = time.perf_counter()
    try:
        return original_strings(self, *args, **kwargs)
    finally:
        strings += time.perf_counter() - start


def timing(self, *args, **kwargs):
    global strings
    cpu.clear()
    counts.clear()
    strings = 0.0
    out = self.out
    self.out = io.StringIO()
    try:
        record = original_timed(self, *args, **kwargs)
    finally:
        self.out = out
    record.update(worker_cpu_seconds=dict(cpu), worker_chunks=dict(counts),
                  strings_seconds=strings,
                  process_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024)
    out.write(json.dumps(record) + "\n")
    out.flush()
    return record


location._NumericDecoder._into = job
StoreReader._strings = string_read
latency.Bench.timed = timing
latency.environment = lambda args: original_env(args) | {"cpu_affinity": sorted(os.sched_getaffinity(0)), "shared_workers": location._DECODE_WORKERS, "fallback_workers": 1}
latency.main()
