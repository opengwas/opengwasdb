"""HTTP timing allocation: 3 numeric + 1 fallback + 2 helpers per host process = 8."""
import os
import runpy
import sys
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0, os.path.join(os.getcwd(), 'scripts/bench'))
import latency
from ogld.store import location
location._DECODE_POOL.shutdown()
location._DECODE_WORKERS = 3
location._DECODE_POOL = ThreadPoolExecutor(max_workers=3, thread_name_prefix='ogld_decode')
environment = latency.environment
latency.environment = lambda args: environment(args) | {'benchmark_allocation': '3 numeric + 1 zarr + 4 HTTP-host helper limit', 'http_host_helper_limit': 4}
runpy.run_path('/data/opengwasdb/work/ogld/scratch/40/phases.py', run_name='__main__')
