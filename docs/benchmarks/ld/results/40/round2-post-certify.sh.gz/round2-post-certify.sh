#!/usr/bin/env bash
set -euo pipefail
export PATH="$HOME/.pixi/bin:$PATH"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 ZARR_THREADING__MAX_WORKERS=1
S=/data/opengwasdb/work/ogld/scratch/40
pixi reinstall --locked -e dev ogld
uptime
taskset -c 0-7 pixi run -e dev python "$S/micro.py"
uptime
# Import and test the archived integration tip without changing cwd or this checkout.
PYTHONSAFEPATH=1 PYTHONPATH="$S/tip" pixi run -e dev python -c 'import ogld; print("TIP_SOURCE", ogld.__file__); assert "/scratch/40/tip/ogld/" in ogld.__file__'
PYTHONSAFEPATH=1 PYTHONPATH="$S/tip:$S/tip/tests:$S/tip/scripts:$S/tip/scripts/realdata" taskset -c 0-7 pixi run -e dev test -n 0 -c "$S/tip/pyproject.toml" "$S/tip/tests"
uptime
echo POST_COMPLETE

for variant in prototype baseline prototype; do
  driver="$S/native-flight-prototype.py"
  if [ "$variant" = baseline ]; then driver="$S/phases.py"; fi
  uptime
  taskset -c 0-7 pixi run -e dev python "$driver" step1 --target local --case clump --cold-only --analyses OGS-00012__GCST90476460 --r2 .01 --zarr-threads 1 --out "$S/flight-$variant.jsonl"
  uptime
done
uptime
taskset -c 0-7 pixi run -e dev python "$S/http-budget.py" step1 --target http10 http50 --case proxies scattered region --seeds 1 --zarr-threads 1 --out "$S/http-bounded-reads.jsonl"
uptime
taskset -c 0-7 pixi run -e dev python "$S/http-budget.py" step1 --target http10 http50 --case clump --cold-only --analyses OGS-00009__ukb-b-4171 OGS-00011__GCST90319613 OGS-00011__GCST90025965 OGS-00011__GCST90029004 --zarr-threads 1 --out "$S/http-bounded-clump.jsonl"
uptime
echo HTTP_BUDGET_COMPLETE
