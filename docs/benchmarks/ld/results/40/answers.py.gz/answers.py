"""Run matrix, region, proxies and clump on the chr22 store; save every answer to an .npz.

Usage: python -P answers.py OUT.npz   (run once with the tip's env, once with the head's)
"""

from __future__ import annotations

import sys
import time

import numpy as np

import ogld

STORE = "/data/opengwasdb/work/ogld/stores/hgdp1kgp-v2-EUR-k10.store"
out: dict[str, np.ndarray] = {}


def keep(name: str, value: object) -> None:
    out[name] = np.asarray(value)


s = ogld.open(STORE)
reader = s._reader
p = s.provenance
start, stop = reader._ranges['22']
n = stop - start
allrows = np.arange(start, stop, dtype=np.int64)
pos = reader.variants(allrows).position.astype(np.int64)
alid = reader.variants(allrows).alid
keep("provenance", [p["near_bp"], p["far_bp"], p["t_far"]])
first, last = int(pos[0]), int(pos[-1])
rng = np.random.default_rng(13)

# M1: row 0, last row, 149 seeded rows from each end's 5 Mb (10 Mb in all).
head_rows = np.flatnonzero((pos > first) & (pos <= first + 5_000_000))
tail_rows = np.flatnonzero((pos >= last - 5_000_000) & (pos < last))
m1 = np.sort(
    np.concatenate(
        [[0, n - 1], rng.choice(head_rows[1:], 149, replace=False),
         rng.choice(tail_rows[:-1], 149, replace=False)]
    )
)
# M2: row 0, the last row, and 298 seeded rows over the first 10 Mb, in a shuffled order.
span = np.flatnonzero((pos > first) & (pos <= first + 10_000_000))
m2 = np.concatenate([[0], rng.choice(span, 298, replace=False), [n - 1]])
rng.shuffle(m2)
# M3: pairs at exactly near_bp, near_bp + 1, far_bp, far_bp + 1 apart, where the panel has them.
edges = []
for d in (p["near_bp"], p["near_bp"] + 1, p["far_bp"], p["far_bp"] + 1, p["far_bp"] - 1):
    j = np.searchsorted(pos, pos + d, side="left")
    hit = np.flatnonzero((j < n) & (pos[np.minimum(j, n - 1)] == pos + d))
    keep(f"edge_count_{d}", len(hit))
    for i in hit[:5]:
        edges.extend([i, j[i]])
m3 = np.array(edges, dtype=np.int64)
keep("m3_rows", m3)

for name, rows in (("m1", m1), ("m2", m2), ("m3", m3)):
    keep(f"{name}_rows", rows)
    ids = list(alid[rows])
    t = time.time()
    m = s.matrix(ids)
    keep(f"{name}_r", m.r)
    keep(f"{name}_kinds", m.kinds())
    keep(f"{name}_alid", m.variants.alid)
    keep(f"{name}_absent", list(m.absent))
    mf = s.matrix(ids, fill=0.0)
    keep(f"{name}_filled", mf.r)
    print(name, m.r.shape, int(np.isnan(m.r).sum()), f"{time.time() - t:.1f}s", flush=True)

t = time.time()
reg = s.region("22", last - 200_000, 5_000_000)
keep("region_r", reg.r)
keep("region_alid", reg.variants.alid)
keep("region_pos", reg.variants.position)
print("region", reg.r.shape, int(np.isnan(reg.r).sum()), f"{time.time() - t:.1f}s", flush=True)

ids = list(alid[m1])
for label, r2 in (("tfar", p["t_far"]), ("08", 0.8)):
    t = time.time()
    px = s.proxies(ids, r2=r2, kb=10_000)
    for col, value in px.columns().items():
        keep(f"proxies_{label}_{col}", value)
    keep(f"proxies_{label}_absent", list(px.absent))
    print("proxies", label, len(px), f"{time.time() - t:.1f}s", flush=True)

hits = np.sort(rng.choice(n, 2000, replace=False))
score = np.abs(rng.normal(size=2000)) * 5
keep("clump_rows", hits)
t = time.time()
cl = s.clump(list(alid[hits]), score, r2=0.01, kb=3_000)
for col, value in cl.columns().items():
    keep(f"clump_{col}", value)
keep("clump_absent", list(cl.absent))
print("clump", len(cl), len(np.unique(cl.lead)), f"{time.time() - t:.1f}s", flush=True)

np.savez(sys.argv[1], **out)
