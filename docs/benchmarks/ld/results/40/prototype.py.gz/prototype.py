import sys, os, time, json, subprocess, hashlib, collections, asyncio
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0, os.path.join(os.getcwd(), 'scripts/bench'))
import latency
import numpy as np
import numcodecs
import zarr
import ogld
from ogld.store import location
from zarr.abc.store import RangeByteRequest, SuffixByteRequest
from zarr.core.buffer import default_buffer_prototype
from zarr.core.sync import sync
zarr.config.set({'threading.max_workers':1})
mode=sys.argv[1]
pool=ThreadPoolExecutor(5)
original=location._fetched

def decode(buf, entries, a, b, size, array):
    out=np.full((b-a)*size,array.fill_value,dtype=array.dtype)
    for k, (offset, length) in enumerate(entries):
        if int(offset)==2**64-1 and int(length)==2**64-1: continue
        raw=numcodecs.Zstd().decode(buf[int(offset):int(offset)+int(length)])
        data=np.frombuffer(raw,dtype=array.dtype.newbyteorder('<'))
        out[k*size:(k+1)*size]=data
    return out[:min(len(out),array.shape[0]-a*size)]

async def direct(array, a,b,size):
    per=array.shards[0]//size
    key=array.metadata.encode_chunk_key((a//per,))
    path=array.store_path/key
    idx=await path.get(default_buffer_prototype(),SuffixByteRequest(per*16+4))
    if idx is None: return np.full(min((b-a)*size,array.shape[0]-a*size),array.fill_value,dtype=array.dtype)
    entries=np.frombuffer(numcodecs.CRC32C().decode(idx.to_bytes()),dtype='<u8').reshape(-1,2)[a%per:a%per+b-a]
    valid=entries[entries[:,0]!=2**64-1]
    if len(valid):
        lo=int(valid[:,0].min()); hi=int(np.max(valid[:,0]+valid[:,1]))
        buf=(await path.get(default_buffer_prototype(),RangeByteRequest(lo,hi))).to_bytes()
        entries=entries.copy(); entries[entries[:,0]!=2**64-1,0]-=lo
    else: buf=b''
    return await asyncio.get_running_loop().run_in_executor(pool,decode,buf,entries,a,b,size,array)

def fetched(array,pieces,size):
    if array.dtype.kind not in 'iuf' or array.shards is None: return original(array,pieces,size)
    async def together(): return await asyncio.gather(*(direct(array,a,b,size) for a,b in pieces))
    return sync(together())
if mode=='prototype':
    location._fetched=fetched
    from ogld.query import clumping
    old=clumping._greedy
    def greedy(reader,rows,scores,**kw):
        lead=np.empty(len(rows),dtype=np.int64); r=np.empty(len(rows))
        for c, members in reader._by_chromosome(rows):
            l,v=old(reader,rows[members],scores[members],**kw); lead[members]=members[l];r[members]=v
        return lead,r
    clumping._greedy=greedy
    oldvar=ogld.store.StoreReader.variants
    from types import SimpleNamespace
    def variants(reader,rows):
        chrom=np.empty(len(rows),dtype='U2');position=np.empty(len(rows),dtype=np.int64)
        for c,m in reader._by_chromosome(rows): chrom[m]=c.name;position[m]=c.position[rows[m]-c.start]
        return SimpleNamespace(alid=reader.alids_of(rows),chrom=chrom,position=position)
    ogld.store.StoreReader.variants=variants
counts=collections.Counter(); keep=location.ChunkCache._keep_run

def counted(self,path,a,b,size,data):
    counts.update((path,k) for k in range(a,b));return keep(self,path,a,b,size,data)
location.ChunkCache._keep_run=counted
analysis=latency.analyses(['OGS-00012__GCST90476460'])[0]
alids,z=latency.hits(analysis,None)
store=latency.published();latency.evict(store)
before=subprocess.getoutput('uptime'); start=time.perf_counter();s=ogld.open(store);c=s.clump(alids,z,r2=.01,kb=3000);seconds=time.perf_counter()-start
h=hashlib.sha256()
for name in ['alid','chrom','position','score','lead','r']:
    a=getattr(c,name); h.update(str(a.dtype).encode());h.update(a.tobytes())
near={k:v for k,v in counts.items() if k[0].startswith('near/')}
print(json.dumps(dict(mode=mode,seconds=seconds,uptime_before=before,uptime_after=subprocess.getoutput('uptime'),leads=len(c.leads()),digest=h.hexdigest(),chunks=sum(counts.values()),distinct=len(counts),near=sum(near.values()),near_distinct=len(near))),flush=True)
pool.shutdown()
