import time, json, threading, runpy, sys
from collections import Counter
from ogld.store import location
from ogld.store.reader import StoreReader
from zarr.storage import LocalStore
T=Counter();lock=threading.Lock(); active=0; peak=0

def timed(owner,name,label):
    old=getattr(owner,name)
    def call(*a,**kw):
        start=time.perf_counter()
        try:return old(*a,**kw)
        finally:
            with lock:T[label]+=time.perf_counter()-start
    setattr(owner,name,call)
for owner,name in [(location,'_fetched'),(location.ChunkCache,'take'),(location.ChunkCache,'_keep_run'),(StoreReader,'rows_of'),(StoreReader,'loci_of'),(StoreReader,'alids_of'),(StoreReader,'_chromosome')]:timed(owner,name,name)
old=location._NumericDecoder._into

def into(*a,**kw):
    global active,peak
    start=time.perf_counter()
    with lock:active+=1;peak=max(peak,active)
    try:return old(*a,**kw)
    finally:
        with lock:
            active-=1;T['worker_seconds']+=time.perf_counter()-start
location._NumericDecoder._into=into
get=LocalStore.get
async def getting(*a,**kw):
    start=time.perf_counter()
    try:return await get(*a,**kw)
    finally:T['store_get_sum']+=time.perf_counter()-start
LocalStore.get=getting
sys.argv=['/tmp/40-probe.py','stages']
runpy.run_path('/tmp/40-probe.py',run_name='__main__')
print(json.dumps({'stage_seconds':dict(T),'decode_peak':peak}),flush=True)
