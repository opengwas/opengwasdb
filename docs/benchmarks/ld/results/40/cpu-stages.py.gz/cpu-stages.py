import time,os,json,threading,runpy
import ogld
from ogld.store import location
lock=threading.Lock();cpu=0.;jobs=0
into=location._NumericDecoder._into

def decode(*a,**kw):
 global cpu,jobs
 start=time.thread_time()
 try:return into(*a,**kw)
 finally:
  with lock:cpu+=time.thread_time()-start;jobs+=1
location._NumericDecoder._into=decode

def threads():
 result={}
 for tid in os.listdir('/proc/self/task'):
  try:
   fields=open(f'/proc/self/task/{tid}/stat').read().rsplit(')',1)[1].split()
   result[tid]=(open(f'/proc/self/task/{tid}/comm').read().strip(),(int(fields[11])+int(fields[12]))/os.sysconf('SC_CLK_TCK'))
  except FileNotFoundError:pass
 return result
before={};original=ogld.open

def opened(*a,**kw):
 global before
 before=threads()
 return original(*a,**kw)
ogld.open=opened
runpy.run_path('/tmp/40-stages.py',run_name='__main__')
after=threads()
print(json.dumps({'decode_worker_cpu':cpu,'decode_jobs':jobs,'thread_cpu_seconds':{name+':'+tid:round(seconds-before.get(tid,('',0))[1],3) for tid,(name,seconds) in after.items()}}),flush=True)
