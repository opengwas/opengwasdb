"""Disposable candidate: use all but one decoded native flight chunk, not half."""
import inspect
import os
import runpy
import sys
import textwrap
sys.path.insert(0, os.path.join(os.getcwd(), 'scripts/bench'))
import latency
from ogld.store import location
source = textwrap.dedent(inspect.getsource(location.ChunkCache.prefetch))
old = 'most = max(1, _FETCH_BYTES // (decoder.size * array.dtype.itemsize) // 2)'
assert old in source
source = source.replace(old, '''most = _FETCH_BYTES // (decoder.size * array.dtype.itemsize)
    most = max(1, most - 1 if decoder.dtype.isnative else most // 2)''')
namespace = vars(location).copy()
exec(compile('from __future__ import annotations\n' + source, __file__, 'exec'), namespace)
location.ChunkCache.prefetch = namespace['prefetch']
environment = latency.environment
latency.environment = lambda args: environment(args) | {'prototype': 'native-flight-all-but-one-chunk; no production change'}
runpy.run_path('/data/opengwasdb/work/ogld/scratch/40/phases.py', run_name='__main__')
