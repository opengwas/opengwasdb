import sys,runpy
sys.setswitchinterval(.0001)
sys.argv=['/tmp/40-probe.py','switch-100us']
runpy.run_path('/tmp/40-probe.py',run_name='__main__')
