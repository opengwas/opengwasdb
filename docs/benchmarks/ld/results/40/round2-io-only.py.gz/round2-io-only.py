"""I/O-only diagnostic: no LD answers are computed or returned."""
import sys,os,time,json,subprocess
sys.path.insert(0,os.path.join(os.getcwd(),'scripts/bench'))
import latency,numpy as np,zarr
from ogld.store import StoreReader,location
from ogld.store.layout import NEAR_R
from ogld.format import REncoding
from ogld.format.geometry import local_rows
zarr.config.set({'threading.max_workers':1});latency.instrument(1,None)
alids,_=latency.hits(latency.analyses(['OGS-00012__GCST90476460'])[0],None)
latency.evict(latency.published());reader=StoreReader.open(latency.published());found=reader.rows_of(alids)
original=location._NumericDecoder._decode;owned=location._NumericDecoder._owned
async def no_decode(self,*args):
 if self.size==NEAR_R[0] and self.dtype.itemsize==REncoding.dtype.itemsize:return
 return await original(self,*args)
def no_output(self,array,k,chunk):
 if array.path.startswith('near/') and array.path.endswith('/r'):
  return np.empty(0,dtype=array.dtype).view(location._DecodedChunk)
 return owned(self,array,k,chunk)
location._NumericDecoder._decode=no_decode;location._NumericDecoder._owned=no_output
latency.TALLY=latency.Tally();before=subprocess.getoutput('uptime');start=time.perf_counter()
for c,members in reader._by_chromosome(found[found>=0]):
 assert reader._prefetch_hits(c,np.unique(local_rows(found[found>=0][members],c.start)),3000000)
seconds=time.perf_counter()-start
print(json.dumps({'kind':'io-only','no_answers_computed':True,'seconds':seconds,'bytes':latency.TALLY.get_bytes.get('near/r',0),'gets':latency.TALLY.gets.get('near/r',0),'uptime_before':before,'uptime_after':subprocess.getoutput('uptime')}),flush=True)
