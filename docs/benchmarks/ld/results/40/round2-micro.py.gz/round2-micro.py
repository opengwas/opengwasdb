"""No answers: compare production job CPU with zstd on the owner's exact shard."""
import concurrent.futures
import json
import subprocess
import time

import numcodecs
import numpy as np
from ogld.store.location import _NumericDecoder

path = '/data/opengwasdb/work/ogld/stores/hgdp1kgp-v2-EUR-k10.store/near/22/r/c/3'
with open(path, 'rb') as handle:
    data = handle.read()
index = np.frombuffer(data[-4100:-4], dtype='<u8').reshape(256, 2)
frames = [memoryview(data)[int(a):int(a+b)] for a,b in index if int(a) != 2**64-1]
decoder = _NumericDecoder(262144, 256, np.dtype('<i2'), np.dtype('<u8'))
for workers in [1,7]:
    for mode in ['allocating', 'out', 'production']:
        def job(group):
            codec=numcodecs.Zstd()
            start=time.thread_time()
            outputs=[]
            for frame in group:
                if mode=='allocating':
                    output=np.frombuffer(codec.decode(frame), dtype='<i2')
                elif mode=='out':
                    output=np.empty(262144, dtype='<i2')
                    codec.decode(frame, out=output)
                else:
                    output=decoder._frame(codec,frame)
                outputs.append(output)
            return time.thread_time()-start, outputs
        before=subprocess.getoutput('uptime')
        start=time.perf_counter()
        cpu=0
        for repeat in range(4):
            with concurrent.futures.ThreadPoolExecutor(workers) as pool:
                results=list(pool.map(job,[frames[k::workers] for k in range(workers)]))
            cpu+=sum(r[0] for r in results)
            del results
        elapsed=time.perf_counter()-start
        print(json.dumps(dict(kind='micro',workers=workers,mode=mode,chunks=4*len(frames),wall_seconds=elapsed,cpu_seconds=cpu,cpu_ms_per_chunk=cpu*1000/(4*len(frames)),wall_ms_per_chunk=elapsed*1000/(4*len(frames)),uptime_before=before,uptime_after=subprocess.getoutput('uptime'))), flush=True)
