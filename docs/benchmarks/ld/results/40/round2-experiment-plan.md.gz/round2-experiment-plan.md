# Resume: ranked residual hypotheses

1. Range-I/O and dispatch still starve decode workers: seven-worker CPU time / (7 × prefetch wall) is about 0.4. A no-decode replay should retain material wall time. Observed: 8.442 s for exactly the same 6,895 Near Band gets and 10.664 GB, no answers computed.
2. Cold ALID strings and chromosome loads dominate the rest of the 37: timing these inside rows_of should explain its roughly 94 s. Observed: 59.094 s strings, 31.113 s chromosome loads. Per-lead partners/bookkeeping total only 14.022 s. Previous sparse/owned-string prototypes did not improve the full query.
3. The conservative half-flight allocation limits useful overlap: letting native prefetch reserve one tail chunk rather than half its budget should improve repeated GCST90476460 cold wall times by >15%, with identical fingerprints and unchanged 256 MiB decoded bound. Test after certification, never concurrently with another benchmark. Keep as a disposable prototype unless the improvement is repeatable; no public knob or memory-limit increase.

The 10 s / 90 s feedback loop remains red. Whole-job CPU and same-shard raw microbenchmarks distinguish a codec cost from scheduling and lookup, without per-frame instrumentation locks.
